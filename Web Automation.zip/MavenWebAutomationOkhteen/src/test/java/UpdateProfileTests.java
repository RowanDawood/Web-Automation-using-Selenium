import Pages.LoginPage;
import Pages.UpdateProfilePage;
import TBases.TBase;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class UpdateProfileTests extends TBase {
    LoginPage login;
    UpdateProfilePage UpdateProfile;

    @BeforeMethod
    public void OpenLogin()throws InterruptedException{
        openBrowser("https://courses.ultimateqa.com");
        login = new LoginPage(driver);
        UpdateProfile = new UpdateProfilePage(driver);
    }

    @Test (priority = 10) //Happy scenario Update all fields
    public void validUpdate() throws InterruptedException {
        SoftAssert soft = new SoftAssert();
        login.loginSteps("julianFady@gmail.com", "pass@word1");
        Thread.sleep(1000);
        UpdateProfile.UpdateSteps("chrisFady@gmail.com","Julian","Fady","orchida","PM");
                                        //Assertions
        Thread.sleep(1000);

        System.out.println("1st Assert with Valid Update Credentials");
        String expectedResult ="Your profile was successfully updated.";
        String actualResult = driver.findElement(By.cssSelector("div[data-message=\"Your profile was successfully updated.\"]")).getText();
        soft.assertTrue(actualResult.contains(expectedResult),"Error Msg: Assert true success Msg Found");

    }

    @AfterMethod
    public void CloseTab()  throws InterruptedException{
        Thread.sleep(3000);
        driver.quit();
    }

}