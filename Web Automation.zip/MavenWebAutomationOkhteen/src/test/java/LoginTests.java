import Pages.LoginPage;
import TBases.TBase;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class LoginTests extends TBase {
    LoginPage login;


    @BeforeMethod
    public void OpenLogin() throws InterruptedException {
        openBrowser("https://courses.ultimateqa.com");
        // Create New Object
        login = new LoginPage(driver);
    }
    @Test (priority = 5)      //empty data
    public void invalidDataLogin_1() throws InterruptedException {

        SoftAssert soft = new SoftAssert();

        login.loginSteps("", "");
        //Assertions
        System.out.println("1st Assert with Empty data ");
        String expectedResult = "Invalid email or password";
        String actualResult = driver.findElement(By.cssSelector("li[class=\"form-error__list-item\"]")).getText();
        Assert.assertTrue(actualResult.contains(expectedResult));

        System.out.println("2nd Assert with URL ");
        Assert.assertEquals(driver.getCurrentUrl(), "https://courses.ultimateqa.com/users/sign_in");
        soft.assertAll();
    }

    @Test (priority = 6)     //empty password
    public void invalidDataLogin_2() throws InterruptedException {

        SoftAssert soft = new SoftAssert();

        login.loginSteps("salem.abdo@gmail.com", "");
        Thread.sleep(10000);
        //Assertions
        System.out.println("1st Assert with Empty password ");
        String expectedResult = "Invalid email or password";
        String actualResult = driver.findElement(By.cssSelector("li[class=\"form-error__list-item\"]")).getText();
        Assert.assertTrue(actualResult.contains(expectedResult));

        System.out.println("2nd Assert with URL ");
        Assert.assertEquals(driver.getCurrentUrl(), "https://courses.ultimateqa.com/users/sign_in");
        soft.assertAll();

        System.out.println("3rd Assert with Empty password ");
        String expectedResult2 = "Forgot Password?";
        String actualResult2 = driver.findElement(By.cssSelector("a[href=\"/users/password/new\"]")).getText();
        Assert.assertTrue(actualResult2.contains(expectedResult2));
    }

    @Test (priority = 7)    //empty Email
    public void invalidDataLogin_3() throws InterruptedException {

        SoftAssert soft = new SoftAssert();

        login.loginSteps("", "12d34weras");
        Thread.sleep(10000);
        //Assertions
        System.out.println("1st Assert with Empty Email ");
        String expectedResult = "Invalid email or password";
        String actualResult = driver.findElement(By.cssSelector("li[class=\"form-error__list-item\"]")).getText();
        Assert.assertTrue(actualResult.contains(expectedResult));

        System.out.println("2nd Assert with URL ");
        Assert.assertEquals(driver.getCurrentUrl(), "https://courses.ultimateqa.com/users/sign_in");
        soft.assertAll();
    }

    @Test (priority = 8)  //Valid Data
    public void validDataLogin() throws InterruptedException {
        SoftAssert soft = new SoftAssert();
        login.loginSteps("julianFady@gmail.com", "pass@word1");
        Thread.sleep(5000);
        //Assertions

        System.out.println("1st Assert");
        soft.assertTrue(driver.findElement(By.cssSelector("a[class=\"dropdown__toggle-button\"]")).isDisplayed());

        System.out.println("2nd Assert");
        String expectedResult2 = "All Courses";
        String actualResult2 = driver.findElement(By.cssSelector("h3[class=\"collections__heading\"]")).getText();
        soft.assertTrue(actualResult2.contains(expectedResult2));

        soft.assertAll();
    }

    @AfterMethod
    public void CloseTab()  throws InterruptedException{
        Thread.sleep(3000);
        driver.quit();

    }

}