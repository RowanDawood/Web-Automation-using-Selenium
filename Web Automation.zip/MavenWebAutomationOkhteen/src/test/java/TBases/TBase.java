package TBases;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TBase {


 public static WebDriver driver ;
    public void openBrowser(String url) throws InterruptedException {
        //1 bridge between Browser & Scripts
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        //Maximize window
        driver.manage().window().maximize();
        //Navigate to Url Per Test Case
        driver.get(url);
    }




}