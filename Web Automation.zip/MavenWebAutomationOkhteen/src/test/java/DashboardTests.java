import Pages.AddItem;
import Pages.LoginPage;
import TBases.TBase;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class DashboardTests extends TBase {
    LoginPage login;
    AddItem Add;

    @BeforeMethod
    public void OpenLogin() throws InterruptedException {
        openBrowser("https://courses.ultimateqa.com");
        // Create New Object
        Add=new AddItem(driver);
        login = new LoginPage(driver);
    }

    @Test (priority = 9)    //Successfully enrolled you in the course //
    public void addToCart() throws InterruptedException {
        SoftAssert soft =new SoftAssert();
        login.loginSteps("chrisFady@gmail.com", "pass@word1");
        Thread.sleep(10000);
        System.out.println("1st Assert with URL ");
        String expectedResult1 = "Signed in successfully.";
        String actualResult1 = driver.findElement(By.cssSelector("div[data-message=\"Signed in successfully.\"]")).getText();
        soft.assertTrue(actualResult1.contains(expectedResult1));

        Add.clickReactCourse().click();
        Thread.sleep(3000);

        System.out.println("2nd Assert with URL ");
        String expectedResult2 = "Get Stated Now";
        String actualResult2 = driver.findElement(By.cssSelector("a[href=\"/enroll/1444729\"]")).getText();
        soft.assertTrue(actualResult2.contains(expectedResult2));

        System.out.println("3rd Assert with URL ");
        soft.assertEquals(driver.getCurrentUrl(), "https://courses.ultimateqa.com/courses/react-and-nodejs");
        driver.findElement(By.cssSelector("a[href=\"/enroll/1444729\"]")).click();
        Thread.sleep(3000);
        driver.navigate().back();

        System.out.println("4th Assert with URL ");
        String expectedResult4 = "Successfully enrolled you in the course";
        String actualResult4 = driver.findElement(By.cssSelector("div[data-message=\"Successfully enrolled you in the course\"]")).getText();
        soft.assertTrue(actualResult4.contains(expectedResult4));

        Thread.sleep(9000);
        driver.findElement(By.cssSelector("img[src=\"https://import.cdn.thinkific.com/3880/atEqmld7THac8c0DZQUz_horizontal_on_transparent_by_logaster.png\"]")).click();

        Add.goDropdown().click();

        driver.findElement(By.xpath("//a[@href=\"/enrollments\"]")).click();

        System.out.println("5th Assertion");
        soft.assertTrue(driver.findElement(By.cssSelector("a[href=\"/courses/react-and-nodejs\"]")).isDisplayed(),"4th Assertion");

        System.out.println("6th Assertion");
        soft.assertEquals(driver.getCurrentUrl(), "https://courses.ultimateqa.com/enrollments");
//        soft.assertAll();
    }

    @AfterMethod
    public void CloseTab()  throws InterruptedException{
        Thread.sleep(3000);
        driver.quit();
    }


}
