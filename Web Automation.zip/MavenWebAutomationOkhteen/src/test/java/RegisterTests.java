import Pages.RegisterPage;
import TBases.TBase;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class RegisterTests extends TBase {
    RegisterPage Register;

    @BeforeMethod
    public void PreRegister()throws InterruptedException{
         openBrowser("https://courses.ultimateqa.com");
         Register = new RegisterPage(driver);
}

    @Test(priority = 1)     //Invalid  with Empty data - only checkbox
    public void emptyDataReg_1() throws InterruptedException {
        SoftAssert soft = new SoftAssert();
        Register.RegSteps("","","","");

        //Assertions
        Thread.sleep(10000);
        System.out.println(" 1st Assert with Empty data ");
      //soft.assertTrue(driver.findElement(By.id("recaptcha-token")).isDisplayed());
        String expectedResult1 ="First name can't be blank";
        String expectedResult2 ="Last name can't be blank";
        String expectedResult3 ="Email can't be blank";
        String expectedResult4 ="Password can't be blank";
        System.out.println(driver.findElement(By.cssSelector("ul[class=\"form-error__list\"]")));
        String actualResult = driver.findElement(By.cssSelector("ul[class=\"form-error__list\"]")).getText();
        soft.assertTrue(actualResult.contains(expectedResult1),"Error Msg: Assert true 1 not Found");
        soft.assertTrue(actualResult.contains(expectedResult2),"Error Msg: Assert true 2 not Found");
        soft.assertTrue(actualResult.contains(expectedResult3),"Error Msg: Assert true 3 not Found");
        soft.assertTrue(actualResult.contains(expectedResult4),"Error Msg: Assert true 4 not Found");
        System.out.println(actualResult);

        System.out.println(" 2nd Assert with Empty data ");
        System.out.println(driver.getCurrentUrl());
        soft.assertEquals(driver.getCurrentUrl(),"https://courses.ultimateqa.com/users","Error Msg: URL Not Found");

        soft.assertAll();

    }

    @Test(priority = 2)     //Invalid Email --> format   .com
    public void invalidDataReg_2() throws InterruptedException {
        SoftAssert soft = new SoftAssert();
        Register.RegSteps("nnmmm","dsdsds","fady@yahoo","123qweas");

        //Assertions
        Thread.sleep(10000);
        System.out.println(" 1st Assert with Invalid Email format");
        //soft.assertTrue(driver.findElement(By.id("recaptcha-token")).isDisplayed());
        String expectedResult ="Email is invalid";
        String actualResult = driver.findElement(By.cssSelector("li[class=\"form-error__list-item\"]")).getText();
        soft.assertTrue(actualResult.contains(expectedResult),"Error Msg: Assert true 1 not Found");
        System.out.println(actualResult);

        System.out.println(" 2nd Assert with Invalid Email format");
        System.out.println(driver.getCurrentUrl());
        soft.assertEquals(driver.getCurrentUrl(),"https://courses.ultimateqa.com/users","Error Msg: URL Not Found");

        soft.assertAll();

    }

    @Test(priority = 3)     //Invalid password constrain 8 characters
    public void invalidDataReg_3() throws InterruptedException {
        SoftAssert soft = new SoftAssert();
        Register.RegSteps("fady","milad","fady601300003@yahoo.com","1234567");

        //Assertions
        Thread.sleep(10000);
        System.out.println(" 1st Assert password constrain 8 characters ");
        //soft.assertTrue(driver.findElement(By.id("recaptcha-token")).isDisplayed());
        String expectedResult ="Password must be at least 8 characters.";
        String actualResult = driver.findElement(By.cssSelector("li[class=\"form-error__list-item\"]")).getText();
        soft.assertTrue(actualResult.contains(expectedResult),"Error Msg: Assert true 1 not Found");
        System.out.println(actualResult);

        System.out.println(" 2nd password constrain 8 characters ");
        System.out.println(driver.getCurrentUrl());
        soft.assertEquals(driver.getCurrentUrl(),"https://courses.ultimateqa.com/users","Error Msg: URL Not Found");

        soft.assertAll();

    }


    @Test(priority = 4)    // Happy scenario for Registration with Valid Credentials
    public void validDataReg() throws InterruptedException {
        SoftAssert soft = new SoftAssert();

        Register.RegSteps("Rrowaan","Dawood","julianFady@gmail.com","pass@word1");

        //Assertions
        Thread.sleep(100);
        System.out.println("1st Assert with Valid Credentials");
        soft.assertTrue(driver.findElement(By.className("collections__heading")).isDisplayed());
        soft.assertTrue(driver.findElement(By.cssSelector("a[data-toggle=\"dropdown\"]")).isDisplayed());

        System.out.println("2nd Assert with Valid Credentials");
        System.out.println(driver.getCurrentUrl());
        soft.assertEquals(driver.getCurrentUrl(),"https://courses.ultimateqa.com/collections","URL Not Found");

        soft.assertAll();

    }

    @AfterMethod
    public void CloseTab()  throws InterruptedException{
        Thread.sleep(3000);
        driver.quit();
    }



}
