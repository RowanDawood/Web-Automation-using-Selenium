package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class UpdateProfilePage {
    private WebDriver driver;
    public UpdateProfilePage (WebDriver driver) {

        this.driver = driver;
    }

    // Go to Dropdown
    public WebElement goDropdown( ) {
        By DropdownToSelect= By.cssSelector("a[data-toggle=\"dropdown\"]");
        WebElement Dropdown=driver.findElement(DropdownToSelect);
        return Dropdown;}

    // Go to My Account
    public WebElement goMyAccount( ) {
        By MyAccountToSelect= By.xpath("//a[@href=\"/account\"]");
        WebElement MyAccount=driver.findElement(MyAccountToSelect);
        return MyAccount;}

    //enterEmail
    public WebElement  updateEmail( ) {
        By EmailToEnter= By.id("user[email]");
        WebElement Email=driver.findElement(EmailToEnter);
        return Email;}

    //enterFName
    public WebElement updateFirstName( ) {
        By FirstnameToEnter= By.id("user[first_name]");
        WebElement FirstName=driver.findElement(FirstnameToEnter);
        return FirstName;
    }

    //enterLName
    public WebElement  updateLastName( ) {
        By LastnameToEnter= By.id("user[last_name]");
        WebElement lastName=driver.findElement(LastnameToEnter);
        return lastName;
    }

    //update Company
    public WebElement updateCompany( ) {
        By CompanyToEnter= By.id("user[profile_attributes][company]");
        WebElement Company=driver.findElement(CompanyToEnter);
        return Company;}

    //update Professional Title
    public WebElement updateProfessionalTitle( ) {
        By ProfessionalTitleToEnter= By.id("user[profile_attributes][headline]");
        WebElement ProfessionalTitle=driver.findElement(ProfessionalTitleToEnter);
        return ProfessionalTitle;
    }

    //update Select Time zone
    public WebElement SelectTimezone( ) {
        WebElement Time=driver.findElement(By.id("user[profile_attributes][timezone]"));
        Select TimeZone =new Select(Time);
       TimeZone.selectByIndex(28);
//        System.out.println(SelectTimezone());
        return TimeZone.getFirstSelectedOption();
    }

    // Submit
   public WebElement SubmitToEnter(){
       By SubmitToEnter=By.cssSelector("input[class=\"button button-primary\"]");
       WebElement Submit=driver.findElement(SubmitToEnter);
       return Submit;
   }
     //   WebElement Submit = driver.findElement(By.cssSelector("input[class=\"button button-primary\"]"));
       // Actions action=new Actions(driver);
      //  action.click(Submit).build().perform();
     //   WebElement Submit=driver.findElement(SubmitToEnter);

    public void UpdateSteps( String Email,String FirstName, String lastName,  String Company,String ProfessionalTitle) throws InterruptedException {

        Thread.sleep(10000);
        goDropdown().click();
        Thread.sleep(20);
        goMyAccount().click();
        Thread.sleep(50);
        updateEmail().clear();
        updateEmail().sendKeys(Email);
        updateFirstName().clear();
        updateFirstName().sendKeys(FirstName);
        Thread.sleep(50);
        updateLastName().clear();
        updateLastName().sendKeys(lastName);
        Thread.sleep(50);
        updateCompany().sendKeys(Company);
        updateProfessionalTitle().sendKeys(ProfessionalTitle);
        Thread.sleep(200);
        SelectTimezone().click();
        Thread.sleep(1000);
      //  driver.findElement(By.cssSelector("input[class=\"button button-primary\"]")).click();
        SubmitToEnter().click();
        Thread.sleep(700);

    }

}
