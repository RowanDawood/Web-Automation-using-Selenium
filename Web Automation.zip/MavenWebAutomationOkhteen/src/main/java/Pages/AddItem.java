package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddItem {

    private WebDriver driver;
    RegisterPage login;
    public AddItem(WebDriver driver) {

        this.driver = driver;
    }
    public WebElement clickReactCourse() {
        WebElement ReactCourse =  driver.findElement(By.cssSelector("a[href=\"/courses/react-and-nodejs\"]"));
        return ReactCourse;
    }

    public WebElement goDropdown( ) {
        By DropdownToSelect= By.cssSelector("a[data-toggle=\"dropdown\"]");
        WebElement Dropdown=driver.findElement(DropdownToSelect);
        return Dropdown;}

}

