package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    private WebDriver driver;
    RegisterPage login;
    public LoginPage(WebDriver driver) {
        login = new RegisterPage(driver);
        this.driver = driver;
    }
    public WebElement enterCheckBox() {
        By ChkBoxToclick = By.id("user[remember_me]");
        WebElement CheckBox = driver.findElement(ChkBoxToclick);
        return CheckBox;
    }
    public void loginSteps(String Email, String Password) throws InterruptedException {

        login.goSignIn().click();
        Thread.sleep(50);
        login.enterEmail().sendKeys(Email);
        Thread.sleep(50);
        login.enterPassword().sendKeys(Password);
        enterCheckBox().click();
        login.enterPassword().sendKeys(Keys.ENTER);
        Thread.sleep(500);
    }
}