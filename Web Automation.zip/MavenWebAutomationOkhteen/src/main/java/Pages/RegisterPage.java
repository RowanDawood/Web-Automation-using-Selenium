package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegisterPage {

   private WebDriver driver;

    public RegisterPage(WebDriver driver) {

       this.driver = driver;
    }
     // Go to SignIn Link
    public WebElement goSignIn( ) {
        By SigninBtnToEnter= By.xpath("//a[@href=\"/users/sign_in\"]");
        WebElement SinginBtn=driver.findElement(SigninBtnToEnter);
        return SinginBtn;}

    // Go to SignUp Link
    public WebElement goSignUp( ) {
        By SingupBtnToEnter= By.xpath("//a[@href=\"/users/sign_up\"]");
        WebElement SingnupBtn=driver.findElement(SingupBtnToEnter);
        return SingnupBtn;}

    //enterFName
    public WebElement enterFirstName( ) {
        By FirstnameToEnter= By.id("user[first_name]");
        WebElement FirstName=driver.findElement(FirstnameToEnter);
        return FirstName;
    }

    //enterLName
    public WebElement  enterLastName(  ) {
        By LastnameToEnter= By.id("user[last_name]");
        WebElement lastName=driver.findElement(LastnameToEnter);
        return lastName;
    }

    //enterEmail
    public WebElement  enterEmail(  ) {
        By EmailToEnter= By.id("user[email]");
        WebElement Email=driver.findElement(EmailToEnter);
        return Email;}

    //enterPassword
    public WebElement  enterPassword(  ) {
        By PasswordToEnter= By.id("user[password]");
        WebElement Password=driver.findElement(PasswordToEnter);
        return Password;}

    //CheckBox
    public WebElement  enterCheckBox(  ) {
        By ChkBoxToclick= By.id("user[terms]");
        WebElement CheckBox=driver.findElement(ChkBoxToclick);
        return CheckBox;
    }

    public void RegSteps(  String FirstName, String lastName, String Email, String Password) throws InterruptedException {

        Thread.sleep(20);
        goSignIn().click();
        Thread.sleep(20);
        goSignUp().click();
        Thread.sleep(20);
        enterFirstName().sendKeys(FirstName);
        Thread.sleep(50);
        enterLastName().sendKeys(lastName);
        Thread.sleep(50);
        enterEmail().sendKeys(Email);
        Thread.sleep(50);
        enterPassword().sendKeys(Password);
        enterCheckBox().click();
        driver.findElement(By.xpath("//input[@type=\"submit\"]")).sendKeys(Keys.ENTER);
        Thread.sleep(1100);

    }
}
